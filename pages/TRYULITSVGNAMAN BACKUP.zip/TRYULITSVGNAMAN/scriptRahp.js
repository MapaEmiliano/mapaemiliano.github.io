const svgMap = document.getElementById("pngMap");
const gridWidth = svgMap.naturalWidth;
const gridHeight = svgMap.naturalHeight;

var paper = Raphael("matrix", gridWidth, gridHeight);

var nodeSize = 40;

var numRows = Math.ceil(gridHeight / nodeSize)  ;
var numCols = Math.ceil(gridWidth / nodeSize);

let grid = new PF.Grid(numCols, numRows),

  finder = new PF.AStarFinder({
    heuristic: PF.Heuristic.octile,
    diagonalMovement: PF.DiagonalMovement.Always
  });

var pathStyle = {
  stroke: "yellow",
  "stroke-width": 5,
};

var rects = [];

window.onload = function () {
  drawGrid();

    // setWalkables();
};

function setWalkables() {
  for (i = 0; i < numRows; ++i) { // HEIGHT
      for (j = 0; j < numCols; ++j) { // WIDTH
            grid.setWalkableAt(j, i, false);
      } 
  }

  let walkArray = [
    [31, 129],
    [31, 128],
    [31, 127],
    [31, 126],
    [31, 125],
    [31, 124],
    [31, 123],
    [31, 122],
    [31, 121],
    [31, 120],
    [31, 119],
    [30, 119],
    [29, 119],
    [28, 119],
    [27, 119],
    [26, 119],
    [25, 119],
    [24, 119],
    [23, 119],
    [22, 119],
  ];

  for (let i = 0; i < walkArray.length; i++) {
    console.log(walkArray[i][0], walkArray[i][1]);
    grid.setWalkableAt(walkArray[i][0], walkArray[i][1], true);
//     if (i = walkArray.length - 1) {
//         // console.log('done');
//   }
}
}

function drawGrid() {

  for (i = 0; i < numRows; ++i) {
    rects.push([]);
    for (j = 0; j < numCols; ++j) {
      x = j * nodeSize;
      y = i * nodeSize;
      rect = paper.rect(x, y, nodeSize, nodeSize);
      rect.attr("fill", "#f00");
      rect.attr("stroke", "#fff");
      rect.attr("class", "recters");
      rects[i].push(rect);
    }
  }

}

function drawPath(path) {
  if (!path.length) {
    console.log("No path found");
    return;
  }
  var svgPath = buildSvgPath2(path);

  this.path = this.paper.path(svgPath).attr(this.pathStyle);
  // this.path = this.paper.path(svgPath).classList.add("kulor");
  console.log(this.path);
}

function clearPath() {
  if (this.path) {
    this.path.remove();
  }
}
/**
 * Given a path, build its SVG represention.
 */

function buildSvgPath2(path) {

  var i, strs = [], size = this.nodeSize;

        strs.push('M' + (path[0][0] * size + size / 2) + ' ' +
                  (path[0][1] * size + size / 2));
        for (i = 1; i < path.length; ++i) {
            strs.push('L' + (path[i][0] * size + size / 2) + ' ' +
                      (path[i][1] * size + size / 2));
        }

        return strs.join('');

}

function toGridCoordinate(pageX, pageY) {
  // console.log(pageX / this.nodeSize, 'and' ,pageY / this.nodeSize);

  return [Math.floor(pageX / this.nodeSize), Math.floor(pageY / this.nodeSize)];
}

let startPos = false;
let prevPath = false;
// let walkArray = [];

setTimeout(function () {
  const gridItem = document.querySelectorAll(".recters");
  gridItem.forEach((item) => {
    item.addEventListener("click", function (e) {
      let curX = this.getAttribute("x");
      let curY = this.getAttribute("y");

      // let pindot = toGridCoordinate(curX, curY);
      // console.log(pindot);

      // walkArray.push(pindot);
      // console.log(walkArray);

      if (startPos) {
        // console.log('Starting: ', startPos);
        let endPos = toGridCoordinate(curX, curY);
        // console.log('Ending: ', endPos);

        let path = finder.findPath(
          startPos[0],
          startPos[1],
          endPos[0],
          endPos[1],
          grid.clone()
        );

        drawPath(path);
        startPos = false;
      } else {
        clearPath();
        startPos = toGridCoordinate(curX, curY);
        // console.log(startPos);
      }
    });
  });
}, 500);