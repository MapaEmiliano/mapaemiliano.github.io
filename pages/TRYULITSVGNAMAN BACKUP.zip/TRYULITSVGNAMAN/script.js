const svgMap = document.getElementById("pngMap");
    const gridWidth = svgMap.naturalWidth;
    const gridHeight = svgMap.naturalHeight;

function makeGrid() {

    let rectRows = gridWidth / 30;
    let rectCols = gridHeight / 30;

    

}